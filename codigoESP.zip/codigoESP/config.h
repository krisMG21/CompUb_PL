#ifndef CONFIG_H
#define CONFIG_H

char* WIFI_SSID = "TCL 10 SE";
char* WIFI_PASS = "datoscris";

char* MQTT_SERVER = "192.168.159.33";
int MQTT_PORT = 1883;
char* MQTT_USER = "ubicua";
char* MQTT_PASS = "ubicua";

#endif // CONFIG_H