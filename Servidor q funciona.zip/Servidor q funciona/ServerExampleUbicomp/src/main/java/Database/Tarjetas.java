/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

// Clase para la tabla Tarjetas
public class Tarjetas {
    private int idTarjeta;

    public Tarjetas() {}

    public Tarjetas(int idTarjeta) {
        this.idTarjeta = idTarjeta;
    }

    public int getIdTarjeta() {
        return idTarjeta;
    }

    public void setIdTarjeta(int idTarjeta) {
        this.idTarjeta = idTarjeta;
    }
}
