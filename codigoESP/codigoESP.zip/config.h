#ifndef CONFIG_H
#define CONFIG_H

char* WIFI_SSID = "Iphone de Martin ";
char* WIFI_PASS = "contrasea";

char* MQTT_SERVER = "172.20.10.2";
int MQTT_PORT = 1883;
char* MQTT_USER = "ubicua";
char* MQTT_PASS = "ubicua";

#endif // CONFIG_H
